# Logo V2 — Blaze Systems

**Approved source:** User-uploaded presentation board dated 20 October 2026.

**Exact source file:** `ORIGINAL/113704.png` (named .png when uploaded, but JPEG encoded); a byte-identical `.jpg` filename is provided for compatibility.

**Source SHA-256:** `56fb15d1ed4faa44af7dafc3defa5e3eb04252966df853bd96f587a7a3d9132d`

**Pixel dimensions:** 1536 × 1024; **format:** JPEG (lossy, pre-existing).

## Elements recorded exactly as printed on the board

- **Brand:** BLAZE SYSTEMS, with the blue ribbon-like B symbol.
- **Pillars:** PEOPLE · TECHNOLOGY · PROGRESS.
- **Tagline:** SYSTEMS THAT EMPOWER A BRIGHTER TOMORROW.
- **Typography:** Montserrat (shown on the board; the package does not bundle licensed font files).
- **Palette:** Blaze Blue `#0066FF`; Electric Blue `#00B0FF`; Deep Blue `#001A3D`; Light Blue `#7DD3FF`.
- **Logo arrangements:** primary, horizontal, stacked, icon only; on dark, on light, monochrome black, monochrome white.
- **Icon sizes listed by board:** 1024×1024, 512×512, 256×256, 128×128 (these are listed specifications, **not** source-resolution deliverables).
- **Three existing photographic mockups:** signage, card/stationery, and hoodie. The files provided here are exact crops of the owner's board, not original separate camera or PSD mockup projects.

## Preserving the owner's artwork

The uploaded image is the **only** art source. The source itself has not been reconstructed, redrawn, replaced, recolored, sharpened, or restyled. Crops only select rectangular portions from the flattened owner-provided raster; their boundaries may retain presentation backgrounds and labels.

- `ORIGINAL/`: byte-identical source, including the source's original filename.
- `EDITOR_FILES/*.psd`: Photoshop-compatible flattened **raster** document. Its pixels are editable; the emblem and type are **not individual vector shapes**.
- `EDITOR_FILES/*.svg`: opens in Adobe Illustrator or Inkscape. This is an image placement with **original JPEG data embedded**, **not** a drawn vector emblem.
- `EDITOR_FILES/*.ora`: layered image document for Krita/GIMP, containing the original reference as one raster layer.
- `ASSETS/`: unchanged-color pixel crops from the owner's reference board, not separately recreated logo artwork.
- `MOCKUPS/`: only the three mockups pictured in the source, cropped without retouching.
- `SAMPLE_APPLICATION/`: basic browser sample showing the image's existing app icon, not a redesigned app UI.

## Source quality and infinite zoom

A 1536×1024 flattened JPEG does not contain original Illustrator paths, editable typography, separated photomontage layers, or enough detail for unlimited enlargement. Saving as PSD, SVG or ORA **does not make this raster infinite-resolution**. Any truly scalable paths would require original authored AI/EPS/SVG/PSD files, or a **new manual redraw/tracing**, which the owner has expressly prohibited. **No invented vector master is included**. Lossless PNG exports retain decoded pixels but cannot recover JPEG details.

**Printed placeholder:** The visual board's `github.com/yourusername/blaze-systems-branding` and QR graphic are part of the approved picture, not a verified official download link. They are intentionally unedited in the reference.
