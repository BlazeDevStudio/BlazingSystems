# Logo V2 — Blaze Systems

**Source:** single user-supplied image, 1536 × 1024 pixels (20 October 2026).

**Non-alteration rule:** These are vector *tracings and crops* of the supplied branding sheet. No generative redraw, added concept, invented use case, or modified wording. Nothing in this package should be taken as recovered original Adobe source files.

## Official visible identity

- Name: **BLAZE SYSTEMS**
- Messages, as supplied: **PEOPLE / TECHNOLOGY / PROGRESS** and **SYSTEMS THAT EMPOWER A BRIGHTER TOMORROW.**
- Displayed typeface name: **Montserrat**. Actual artwork wordmark characters have been traced as **editable vector outlines**, not replaced with a substitute font. Text in outlines is not editable as typed text.
- Palette: Blaze Blue `#0066FF`; Electric Blue `#00B0FF`; Deep Blue `#001A3D`; Light Blue `#7DD3FF`.
- Presented treatments: primary, horizontal, stacked, icon-only, dark background, light background, monochrome black, monochrome white.
- App icon sizes shown: **1024×1024, 512×512, 256×256, 128×128**.
- Application/mockup contexts visibly supplied: mobile app icons, wall signage, stationery, apparel/garment.

## Editing

- `vector/*.svg` is the **editable vector master**, opens in Inkscape, Adobe Illustrator and compatible vector applications. Group transform positions, path points and colors can be edited. Gradients and traced outlines remain vectors.
- `vector/*.pdf` are vector exports usable by Illustrator and compatible editors. Illustrator-native `.ai`, Photoshop-native `.psd` or `.eps` source project files **are NOT recovered** from a JPEG and are not falsely represented as originals.
- `png-exports/` is rendered from the SVGs at large dimensions, not upscaled from the original low-resolution logo.
- `source-mockups/` are 4× upscaled, lightly sharpened **cropped photos from the reference**. They remain raster imagery; no new photographic details are claimed.

## Fidelity disclaimer

The icon contours, highlight regions, wordmark outlines and app icon proportions were traced from a rasterized brand board. An image trace cannot mathematically guarantee a 1:1 match against unseen original paths, vector gradients or layers. Inspect the SVGs against the reference before accepting them as official production master assets. The single user-provided JPEG is intentionally **not** redistributed within this ZIP.

## Source attribution

Design rights and original source: the user's supplied Blaze Systems logo. Packaging/tracing does not imply ownership or authorship of the original design.
