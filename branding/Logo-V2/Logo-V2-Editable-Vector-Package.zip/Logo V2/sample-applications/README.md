# Sample applications — Logo V2

Only the examples shown on the supplied sheet are documented: rounded-square app icon variants, wall signage, stationery, and garment. See `vector/Logo-V2-App-*.svg` for editable app-icon implementations and `source-mockups/` for source-based photographic examples. No new usage concept has been added.
